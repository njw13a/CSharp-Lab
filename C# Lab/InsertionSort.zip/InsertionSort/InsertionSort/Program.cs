﻿using System;
using System.Collections.Generic;

namespace InsertionSort
{
	class MainClass
	{
		static void print(int[] A, int size)
		{
			Console.Write(A[0]);
			for (int i = 1; i < size; i++)
			{
				Console.Write(", " + A[i]);
				//Console.WriteLine(A[i]);
			}
			Console.WriteLine("\n");
		}

		static int[] InsertionSort(int[] inputarray)
		{
			for (int i = 0; i < inputarray.Length - 1; i++)
			{
				int j = i + 1;

				while (j > 0)
				{
					if (inputarray[j - 1] > inputarray[j])
					{
						int temp = inputarray[j - 1];
						inputarray[j - 1] = inputarray[j];
						inputarray[j] = temp;

					}
					j--;
				}
			}
			return inputarray;
		}

		public static void Main()
		{
			int[] A = { 5, 7, 2, 3, 6, 0, 9, 1, 8, 4 };
			int size = 10;

			InsertionSort(A);

			print(A, size);
		}
	}
}
